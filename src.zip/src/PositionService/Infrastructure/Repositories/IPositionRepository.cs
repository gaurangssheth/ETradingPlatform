﻿using PositionService.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PositionService.Infrastructure.Repositories
{
    public interface IPositionRepository : IGenericRepository<Position>
    {
        Task<Position?> GetByClientAndInstrumentIdAsync(string clientId, Guid instrumentId, CancellationToken cancellationToken = default);

        Task<IReadOnlyList<Position>> GetOpenPositionsAsync(CancellationToken cancellationToken = default);

        Task<IReadOnlyList<Position>> GetOpenPositionsBySymbolAsync(string symbol, CancellationToken cancellationToken = default);

        Task<IReadOnlyList<Position>> GetOpenPositionsByClientIdAsync(string clientId, CancellationToken cancellationToken = default);

    }
}
