using RiskService.Grpc.Configuration;
using RiskService.Grpc.Services;

Console.Title = "ETrading - RiskService.Grpc";
Console.WriteLine("RiskService.Grpc is running.");

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddSerilogConfiguration(builder.Environment);
builder.UseSerilogConfiguration();

// Add services to the container.
builder.Services.AddGrpc();
builder.Services.ConfigureServices(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<GreeterService>();
app.MapGrpcService<RiskGrpcService>();

app.MapGet("/", () => "RiskService.Grpc is running. Use a gRPC client to call CheckOrderRisk.");

app.Run();
