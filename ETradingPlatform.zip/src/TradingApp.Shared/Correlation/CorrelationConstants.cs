﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.Shared.Correlation
{
    public static class CorrelationConstants
    {
        public const string HeaderName = "X-Correlation-Id";

        public const string LogPropertyName = "CorrelationId";
    }
}
