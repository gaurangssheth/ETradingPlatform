﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PositionService.Domain
{
    public class Position
    {
        public Guid Id { get; set; }
        public string ClientId { get; set; } = null!;
        public Guid InstrumentId { get; set; }
        public AssetClass AssetClass { get; set; }
        public string Symbol { get; set; } = null!;
        public decimal NetQuantity { get; set; }
        public decimal AveragePrice { get; set; }
        public CurrencyCode PnlCurrency { get; set; }
        public decimal RealisedPnl { get; set; }

        // Placeholder for Phase 2B.
        // Later this will be calculated using market price from PricingService.Grpc.
        public decimal UnrealisedPnl { get; set; }
        public string CorrelationId { get; set; } = null!;
        public DateTimeOffset CreatedAt { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
        public ICollection<PositionMovement> Movements { get; set; } = new List<PositionMovement>();
        public long AccountingVersion { get; set; }
    }
}
