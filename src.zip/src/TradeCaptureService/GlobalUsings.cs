﻿global using TradingApp.SharedKernel;
