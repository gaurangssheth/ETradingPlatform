Write-Host "======================================="
Write-Host "Cleaning solution..."
Write-Host "======================================="

Get-ChildItem -Directory -Recurse -Force |
Where-Object { $_.Name -in @("bin","obj") } |
Remove-Item -Recurse -Force

if (Test-Path ".vs")
{
    Remove-Item ".vs" -Recurse -Force
}

if (Test-Path "ETradingPlatform.zip")
{
    Remove-Item "ETradingPlatform.zip"
}

Write-Host ""
Write-Host "======================================="
Write-Host "Creating zip..."
Write-Host "======================================="

Compress-Archive `
    -Path * `
    -DestinationPath ETradingPlatform.zip `
    -CompressionLevel Optimal

Write-Host ""
Write-Host "Done!"