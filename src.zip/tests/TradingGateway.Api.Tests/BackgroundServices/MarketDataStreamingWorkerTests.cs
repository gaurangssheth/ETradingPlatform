﻿using FluentAssertions;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TradingGateway.Api.BackgroundServices;
using TradingGateway.Api.ClientModels;
using TradingGateway.Api.Clients;
using TradingGateway.Api.Hubs;

namespace TradingGateway.Api.Tests.BackgroundServices
{
    public class MarketDataStreamingWorkerTests
    {
        [Fact]
        public async Task ExecuteAsync_ShouldBroadcastMarketQuoteUpdated()
        {
            using var cancellationTokenSource = new CancellationTokenSource();

            var quote = CreateQuote();

            var quoteBroadcast = new TaskCompletionSource<(string Method, object[] Arguments)>(
                TaskCreationOptions.RunContinuationsAsynchronously);

            var streamCancelled = new TaskCompletionSource(
                TaskCreationOptions.RunContinuationsAsynchronously);

            var pricingServiceClient = CreatePricingServiceClient(quote, streamCancelled, cancellationTokenSource.Token);

            var hubContext = CreateHubContext(quoteBroadcast, out var clientProxy);

            var marketDataStreamingWorker = CreateWorker(pricingServiceClient, hubContext);

            await marketDataStreamingWorker.StartAsync(CancellationToken.None);

            var broadcast = await quoteBroadcast.Task;

            broadcast.Method.Should().Be("MarketQuoteUpdated");
            broadcast.Arguments.Should().ContainSingle();
            broadcast.Arguments[0].Should().BeSameAs(quote);

            cancellationTokenSource.Cancel();

            await streamCancelled.Task;

            cancellationTokenSource.IsCancellationRequested.Should().BeTrue();

            await marketDataStreamingWorker.StopAsync(CancellationToken.None);
        }

        private static MarketQuoteResponse CreateQuote()
        {
            return new MarketQuoteResponse
            {
                Symbol = "EURUSD",
                Bid = 1.0850m,
                Ask = 1.0852m,
                Timestamp = DateTimeOffset.UtcNow
            };
        }

        private static Mock<IPricingServiceClient> CreatePricingServiceClient(
            MarketQuoteResponse quote,
            TaskCompletionSource streamCancelled,
            CancellationToken cancellationToken)
        {
            var pricingServiceClient =
                new Mock<IPricingServiceClient>();

            pricingServiceClient.Setup(x => x.StreamMarketQuotesAsync(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns((string _, CancellationToken _) => 
                    GetQuotesAsync(quote, streamCancelled, cancellationToken));

            return pricingServiceClient;
        }

        private static async IAsyncEnumerable<MarketQuoteResponse> GetQuotesAsync(
            MarketQuoteResponse quote,
            TaskCompletionSource streamCancelled,
            [EnumeratorCancellation]
            CancellationToken cancellationToken = default)
        {
            yield return quote;

            try
            {
                await Task.Delay(Timeout.Infinite,
                    cancellationToken);
            }
            catch (OperationCanceledException)
                when (cancellationToken.IsCancellationRequested)
            {
                streamCancelled.TrySetResult();

                yield break;
            }
        }

        private static Mock<IHubContext<MarketDataHub>> CreateHubContext(
            TaskCompletionSource<(string Method, object[] Arguments)> quoteBroadcast,
            out Mock<IClientProxy> clientProxy)
        {
            clientProxy = new Mock<IClientProxy>();

            clientProxy
                .Setup(x => x.SendCoreAsync(
                    "MarketQuoteUpdated",
                    It.IsAny<object[]>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, object[], CancellationToken>((method, arguments, _) =>
                {
                    quoteBroadcast.TrySetResult((method, arguments));
                })
                .Returns(Task.CompletedTask);

            var hubClients = new Mock<IHubClients>();

            hubClients
                .SetupGet(x => x.All)
                .Returns(clientProxy.Object);

            var hubContext = new Mock<IHubContext<MarketDataHub>>();

            hubContext
                .SetupGet(x => x.Clients)
                .Returns(hubClients.Object);

            return hubContext;
        }

        private static MarketDataStreamingWorker CreateWorker(
            Mock<IPricingServiceClient> pricingServiceClient,
            Mock<IHubContext<MarketDataHub>> hubContext)
        {
            var serviceProvider = new Mock<IServiceProvider>();

            serviceProvider
                .Setup(x => x.GetService(
                    typeof(IPricingServiceClient)))
                .Returns(
                    pricingServiceClient.Object);

            var serviceScope = new Mock<IServiceScope>();

            serviceScope
                .SetupGet(x => x.ServiceProvider)
                .Returns(serviceProvider.Object);

            var serviceScopeFactory =
                new Mock<IServiceScopeFactory>();

            serviceScopeFactory
                .Setup(x => x.CreateScope())
                .Returns(serviceScope.Object);

            return new MarketDataStreamingWorker(
                serviceScopeFactory.Object,
                hubContext.Object,
                NullLogger<MarketDataStreamingWorker>.Instance);
        }
    }
}
